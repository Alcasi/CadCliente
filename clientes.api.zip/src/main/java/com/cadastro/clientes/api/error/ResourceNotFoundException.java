package com.cadastro.clientes.api.error;

public class ResourceNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 8953631407874355973L;

		public ResourceNotFoundException(String mensagem) {
			super(mensagem);
		}
}
