package com.cadastro.clientes.api.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cadastro.clientes.api.models.Cliente;

public interface ClienteRepository extends JpaRepository<Cliente, Long>{
	List<Cliente> findByCadastroAtivo(boolean cadastroAtivo);
}
