package com.cadastro.clientes.api.resources;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cadastro.clientes.api.error.ResourceNotFoundException;
import com.cadastro.clientes.api.models.Cliente;
import com.cadastro.clientes.api.repository.ClienteRepository;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value="/api")
@Api(value="API REST Cadastro de Clientes")
@CrossOrigin(origins="*")
public class ClienteResource {

	@Autowired
	ClienteRepository clienteRepository;
	
	@GetMapping("/clientes")
	@ApiOperation(value="Este método lista todos os clientes")
	public List<Cliente> listaClientes(){
		
		List<Cliente> clientes = clienteRepository.findAll();
		
		if (clientes == null || clientes.isEmpty()) {
			throw new ResourceNotFoundException("Nenhum cliente encontrado!");
		}
		
		return clientes;
	}

	@GetMapping("/clientesAtivos")
	@ApiOperation(value="Este método lista todos os clientes ativos")
	public List<Cliente> listaClientesAtivos(){
		
		List<Cliente> clientes = clienteRepository.findByCadastroAtivo(true);
		
		if (clientes == null || clientes.isEmpty()) {
			throw new ResourceNotFoundException("No momento não existe nenhum cliente ativo");
		}
		
		return clientes;
		
	}
	
	@PostMapping("/clientes")
	@ApiOperation(value="Este método inclui um novo cliente")
	public Cliente salvaCliente(@RequestBody Cliente cliente) {
		return clienteRepository.save(cliente);
	}

	@DeleteMapping("/clientes/{id}")
	@ApiOperation(value="Este método apaga um cliente")
	public void deletaCliente(long id) {
		try {
			clienteRepository.deleteById(id);
		}catch (Exception ex) {
			throw new ResourceNotFoundException("Erro ao deletar");
		}
	}

	@PutMapping("/clientes")
	@ApiOperation(value="Este método atualiza os dados de um cliente")
	public Cliente atualizaCliente(@RequestBody Cliente cliente) {
		return clienteRepository.save(cliente);
	}

	
}
